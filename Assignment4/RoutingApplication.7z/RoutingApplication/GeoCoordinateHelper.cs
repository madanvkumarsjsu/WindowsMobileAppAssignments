﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Device.Location;
using RoutingApplication.GeocodeService;
using Microsoft.Phone.Controls.Maps;
using System.Collections.ObjectModel;

namespace RoutingApplication
{
    public class GeoCoordinateHelper
    {
        private string _applicationId;
        private GeocodeService.GeocodeServiceClient _geocodeService;

        public delegate void LocationFoundEventHandler(GeoCoordinate e);
        public event LocationFoundEventHandler LocationFound;
        public delegate void AddressFoundEventHandler(Address e);
        public event AddressFoundEventHandler AddressFound;

        public GeoCoordinateHelper(string applicationId)
        {
            _applicationId = applicationId;
            InitService();
        }

        private void InitService()
        {
            // Create the service variable and set the callback method using the GeocodeCompleted property.
            _geocodeService = new GeocodeService.GeocodeServiceClient("BasicHttpBinding_IGeocodeService");
            _geocodeService.GeocodeCompleted += new EventHandler<GeocodeService.GeocodeCompletedEventArgs>(geocodeService_GeocodeCompleted);
            _geocodeService.ReverseGeocodeCompleted += new EventHandler<GeocodeService.ReverseGeocodeCompletedEventArgs>(geocodeService_ReverseGeocodeCompleted);

        }
        public void FindAddress(string addressText)
        {
            // Set the credentials 
            GeocodeService.GeocodeRequest geocodeRequest = new GeocodeService.GeocodeRequest();
            geocodeRequest.Credentials = new Credentials();
            // new GeocodeService.Credentials();
            geocodeRequest.Credentials.ApplicationId = _applicationId;
            //((ApplicationIdCredentialsProvider)demoMap.CredentialsProvider).ApplicationId;
            // Set the geocode query, which could be an address or location.
            geocodeRequest.Query = addressText;
            ////Only accept results with high confidence
            geocodeRequest.Options = new GeocodeService.GeocodeOptions();
            GeocodeService.ConfidenceFilter filter = new GeocodeService.ConfidenceFilter();
            filter.MinimumConfidence = GeocodeService.Confidence.High;

            geocodeRequest.Options.Filters = new ObservableCollection<GeocodeService.FilterBase>();
            geocodeRequest.Options.Filters.Add(filter);

            // Now make the asynchronous Geocode request
            _geocodeService.GeocodeAsync(geocodeRequest);
        }

        void geocodeService_GeocodeCompleted(object sender, GeocodeService.GeocodeCompletedEventArgs e)
        {
            // Check if geocode was successful
            if (e.Result.Results.Count == 0)
            {
                MessageBox.Show("Could not find address");
                return;
            }
            GeocodeService.GeocodeLocation geocodeLocation = e.Result.Results[0].Locations[0];
            if (geocodeLocation != null)
            {
                LocationFound(new GeoCoordinate(geocodeLocation.Latitude, geocodeLocation.Longitude));
            }
        }

        public void Reverse_Geocode(GeoCoordinate location)
        {
            // Set the credentials.
            GeocodeService.ReverseGeocodeRequest ReverseGeocodingRequest = new GeocodeService.ReverseGeocodeRequest();
            ReverseGeocodingRequest.Credentials = new Credentials();
            ReverseGeocodingRequest.Credentials.ApplicationId = _applicationId;

            // Set the location for the reverse geocoding
            ReverseGeocodingRequest.Location = location;
            //Execute Reverse Geocoding 
            _geocodeService.ReverseGeocodeAsync(ReverseGeocodingRequest);
        }

        void geocodeService_ReverseGeocodeCompleted(object sender, GeocodeService.ReverseGeocodeCompletedEventArgs e)
        {
            if (e.Result.Results.Count > 0)
            {
                AddressFound(e.Result.Results[0].Address);
            }
        }
    }
}
