﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Maps;
using System.Device.Location;
using System.Threading;
using System.Diagnostics;
using Microsoft.Phone.Controls.Maps.Platform;
using System.Globalization;
using Microsoft.Phone.Shell;
using RoutingApplication.RouteService;
using System.Collections.ObjectModel;

namespace RoutingApplication
{
    public partial class MainPage : PhoneApplicationPage
    {
        private GeoCoordinateWatcher geoWatcher;
        private MapLayer posLayer;
        private Pushpin demoPushin;
        private GeoCoordinateHelper geocode;
        private RoutingHelper routing;
        bool draggingNow = false;
        RouteServiceClient routeService = null;
        Pushpin StartMarker = null;
        Pushpin EndMarker = null;
        String startString = "Start";
        String endString = "End";
        bool StartDragging = true;
        MapPolyline routePolyline = null;
        String ApplicationId = "Aq8WxN4LNFurrUFOIVtLHJmyVNTHODUwoBoMJ7AAeXkusO_0rX4ytvfS6NWdS_Vj";
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            Debug.WriteLine("We are started"); //Check to see if the "Redirect all Output Window text to the Immediate Window" is checked under Tools -> Options -> Debugging -> General.  

            myMaps.MouseLeftButtonUp += new MouseButtonEventHandler(map_MouseLeftButtonUp);
            myMaps.MouseMove += new MouseEventHandler(map_MouseMove);
            myMaps.MapPan += map_MousePan;

            StartMarker = new Pushpin();
            StartMarker.Content = startString;
            StartMarker.Location = new GeoCoordinate(60.24, 24.88);
            StartMarker.MouseLeftButtonUp += new MouseButtonEventHandler(Marker_MouseLeftButtonUp);
            StartMarker.MouseLeftButtonDown += new MouseButtonEventHandler(Marker_MouseLeftButtonDown);

            EndMarker = new Pushpin();
            EndMarker.Content = endString;
            EndMarker.Location = new GeoCoordinate(60.24, 24.87);
            EndMarker.MouseLeftButtonUp += new MouseButtonEventHandler(Marker_MouseLeftButtonUp);
            EndMarker.MouseLeftButtonDown += new MouseButtonEventHandler(Marker_MouseLeftButtonDown);

            myMaps.Children.Add(EndMarker);
            myMaps.Children.Add(StartMarker);

            routeService = new RouteServiceClient("BasicHttpBinding_IRouteService");
            routeService.CalculateRouteCompleted += new EventHandler<CalculateRouteCompletedEventArgs>(routeService_CalculateRouteCompleted);
            //Initialize posLayer
            posLayer = new MapLayer();
            posLayer.Name = "Layer1";
            myMaps.Children.Add(posLayer);
            posLayer.Visibility = Visibility.Visible;

            //Initialize demoPushpin
            demoPushin = new Pushpin();
            demoPushin.Name = "Pushpin1";
            demoPushin.Content = "You are here";
            posLayer.Children.Add(demoPushin);
            demoPushin.Visibility = Visibility.Collapsed;
            
            InitWatcher();
            
        }
        private void InitWatcher()
        {
            geoWatcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
            geoWatcher.MovementThreshold = 20;
            geoWatcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(geoWatcher_StatusChanged);
            geoWatcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(geoWatcher_PositionChanged);
            //geoWatcher.Start();
            new Thread(backgroundLocationService).Start();
             
        }

        private void InitGeocode()
        {
            if (geocode == null)
            {
                geocode = new GeoCoordinateHelper(((ApplicationIdCredentialsProvider)myMaps.CredentialsProvider).ApplicationId);
                geocode.LocationFound += new GeoCoordinateHelper.LocationFoundEventHandler(geocode_LocationFound);
                geocode.AddressFound += new GeoCoordinateHelper.AddressFoundEventHandler(geocode_AddressFound);
            }
        }

        private void InitRouting()
        {
            if (routing == null)
            {
                routing = new RoutingHelper(((ApplicationIdCredentialsProvider)myMaps.CredentialsProvider).ApplicationId);
                routing.RouteCalculated += new RoutingHelper.RouteCalculateEventHandler(routing_RouteCalculated);
            }
        }

        private void btnLocate_Click(object sender, RoutedEventArgs e)
        {
            InitGeocode();
            geocode.FindAddress(txtAddress.Text);
        }

        private void btnMyAddress_Click(object sender, RoutedEventArgs e)
        {
            InitGeocode();
            geocode.Reverse_Geocode(demoPushin.Location);
        }

        /*private void btnRouteMe_Click(object sender, RoutedEventArgs e)
        {
            InitRouting();
            List<Pushpin> wayPoints = new List<Pushpin>();
            foreach (Pushpin ps in posLayer.Children.OfType<Pushpin>())
            {
                wayPoints.Add(ps);
            }
            routing.CalculateRoute(wayPoints);

        }*/
        void geocode_AddressFound(GeocodeService.Address e)
        {
            demoPushin.Content = e.FormattedAddress;
            myMaps.Center = demoPushin.Location;
        }
        void routing_RouteCalculated(MapLayer layer, LocationRect rect, string directions)
        {
            myMaps.Children.Add(layer);
            myMaps.SetView(rect);
        }
        void geocode_LocationFound(GeoCoordinate e)
        {
            Pushpin ps = new Pushpin();
            posLayer.Children.Add(ps);
            ps.Content = txtAddress.Text;
            ps.Location = e;
            ps.Visibility = Visibility.Visible;
            myMaps.Center = e;
        }

        void geoWatcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            GeoCoordinate Loc = new GeoCoordinate(e.Position.Location.Latitude, e.Position.Location.Longitude);
            demoPushin.Location = Loc;
            //demoPushin.Location = e.Position.Location;
            demoPushin.Content = "You are here!";
            demoPushin.Visibility = Visibility.Visible;
            myMaps.Center = e.Position.Location;
            myMaps.ZoomLevel = 18;
            Console.WriteLine("LAT:" + geoWatcher.Position.Location.Latitude);
            Console.WriteLine("LAT:" + geoWatcher.Position.Location.Longitude);
            //myMaps.Center = new GeoCoordinate(geoWatcher.Position.Location.Latitude, geoWatcher.Position.Location.Longitude);

        }

        void geoWatcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    if (geoWatcher.Permission == GeoPositionPermission.Denied)
                    {
                        // The user has disabled the Location Service on their device.
                        MessageBox.Show("You have disabled Location Service.");
                    }
                    else
                    {
                        MessageBox.Show("Location Service is not functioning on this device.");
                    }
                    break;
                case GeoPositionStatus.Initializing:
                    txbGPSStatus.Text = "Location Service is retrieving data...";
                    // The Location Service is initializing.
                    break;
                case GeoPositionStatus.NoData:
                    // The Location Service is working, but it cannot get location data.
                    txbGPSStatus.Text = "Location data is not available.";
                    break;
                case GeoPositionStatus.Ready:
                    // The Location Service is working and is receiving location data.
                    txbGPSStatus.Text = "Location data is available.";
                    break;
            }
        }
        void backgroundLocationService()
        {
            geoWatcher.TryStart(true, TimeSpan.FromSeconds(1));
        }

        void map_MousePan(object sender, MapDragEventArgs e)
        {
            Debug.WriteLine("map_MousePan");

            if (StartMarker != null && EndMarker != null && draggingNow)
            {
                e.Handled = true;
            }
        }

        void map_MouseMove(object sender, MouseEventArgs e)
        {
            Debug.WriteLine("map_MouseMove");

            if (StartMarker != null && EndMarker != null && draggingNow)
            {
                if (StartDragging)
                {
                    StartMarker.Location = myMaps.ViewportPointToLocation(e.GetPosition(myMaps));
                }
                else
                {
                    EndMarker.Location = myMaps.ViewportPointToLocation(e.GetPosition(myMaps));
                }
            }
        }

        void map_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("map_MouseLeftButtonUp");
            draggingNow = false;
        }

        void Marker_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("StartMarker_MouseLeftButtonDown");
            if (StartMarker != null && EndMarker != null)
            {
                draggingNow = true;

                Pushpin selected = sender as Pushpin;


                if (selected == StartMarker)
                {
                    StartDragging = true;
                }
                else
                {
                    StartDragging = false;
                }

                Debug.WriteLine("selected :" + selected.Content + ", start drag: " + StartDragging);
            }
        }

        void Marker_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("StartMarker_MouseLeftButtonUp");
            draggingNow = false;
        }

        private void btnRouteMe_Click(object sender, EventArgs e)
        {
            RouteRequest routeRequest = new RouteRequest();

            // Set the credentials using a valid Bing Maps key
            routeRequest.Credentials = new RouteService.Credentials();
            routeRequest.Credentials.ApplicationId = ApplicationId;

            var waypoint1 = new Waypoint();
            waypoint1.Description = "Start";
            waypoint1.Location = new RoutingApplication.RouteService.Location();
            waypoint1.Location.Latitude = StartMarker.Location.Latitude;
            waypoint1.Location.Longitude = StartMarker.Location.Longitude;

            var waypoint2 = new Waypoint();
            waypoint2.Description = "End";
            waypoint2.Location = new RoutingApplication.RouteService.Location();
            waypoint2.Location.Latitude = EndMarker.Location.Latitude;
            waypoint2.Location.Longitude = EndMarker.Location.Longitude;

            routeRequest.Waypoints = new ObservableCollection<Waypoint>();
            routeRequest.Waypoints.Add(waypoint1);
            routeRequest.Waypoints.Add(waypoint2);

            routeService.CalculateRouteAsync(routeRequest);
        }

        void routeService_CalculateRouteCompleted(object sender, CalculateRouteCompletedEventArgs e)
        {

            if (routePolyline != null)
            {
                myMaps.Children.Remove(routePolyline);
                routePolyline = null;
            }

            // The result is an RouteResponse Object
            RouteResponse routeResponse = e.Result;

            Debug.WriteLine("ResponseSummary.StatusCode: " + routeResponse.ResponseSummary.StatusCode);
            Debug.WriteLine("ResponseSummary.FaultReason: " + routeResponse.ResponseSummary.FaultReason);

            Debug.WriteLine("Points.Count: " + routeResponse.Result.RoutePath.Points.Count);
            Debug.WriteLine("Legs.Count: " + routeResponse.Result.Legs.Count);


            if (routeResponse.Result.Legs.Count > 0 && routeResponse.Result.Legs[0].Itinerary.Count > 0)
            {
                Debug.WriteLine("Itinerary.Count: " + routeResponse.Result.Legs[0].Itinerary.Count);

                var locations = new LocationCollection();

                for (int i = 0; i < routeResponse.Result.Legs[0].Itinerary.Count; i++)
                {
                    GeoCoordinate newpoint = new GeoCoordinate();
                    newpoint.Latitude = routeResponse.Result.Legs[0].Itinerary[i].Location.Latitude;
                    newpoint.Longitude = routeResponse.Result.Legs[0].Itinerary[i].Location.Longitude;
                    locations.Add(newpoint);
                }

                routePolyline = new MapPolyline();
                routePolyline.Opacity = 0.7;
                routePolyline.Locations = locations;
                routePolyline.Stroke = new SolidColorBrush(Colors.Green);
                routePolyline.StrokeThickness = 4;

                myMaps.Children.Add(routePolyline);
            }
            else
            {
                Debug.WriteLine("No Route found");
            }

            
        }
    }
}